package Zadatak1;

import java.util.ArrayList;
import java.util.List;

public class Prodavnica {
    public static List<EProizvodi> filterByType(List<EProizvodi> proizvodi, String tip) {
        List<EProizvodi> out = new ArrayList<>();
        if (tip == null) return out;
        String t = tip.trim().toUpperCase();
        if (t.length() > 2) t = t.substring(0, 2);
        for (EProizvodi p : proizvodi) {
            if (p == null) continue;
            if (p.tip().equals(t)) out.add(p);
        }
        return out;
    }
}
