package Zadatak1;

public abstract class EProizvodi {
    protected String opis;
    protected String sifra;
    protected double uvoznaCijena; 

    public EProizvodi(String opis, String sifra, double uvoznaCijena) {
        this.opis = opis;
        this.sifra = sifra;
        this.uvoznaCijena = uvoznaCijena;
    }

    public String getOpis() {
        return opis;
    }

    public String getSifra() {
        return sifra;
    }

    public double getUvoznaCijena() {
        return uvoznaCijena;
    }

    public double osnovnaMaloprodajnaCijena() {
        return uvoznaCijena * 1.05; 
    }

    public abstract double maloprodajnaCijena();

    public String tip() {
        if (sifra == null || sifra.length() < 2) return "--";
        return sifra.substring(0, 2).toUpperCase();
    }

    @Override
    public String toString() {
        return String.format("%s | %s | Uvozna: %.2f | Maloprodajna: %.2f", opis, sifra, uvoznaCijena, maloprodajnaCijena());
    }
}