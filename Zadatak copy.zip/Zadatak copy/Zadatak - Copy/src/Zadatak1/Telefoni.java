package Zadatak1;

public class Telefoni extends EProizvodi {
    private String operativniSistem;
    private double velicinaEkrana; 

    public Telefoni(String opis, String sifra, double uvoznaCijena, String operativniSistem, double velicinaEkrana) {
        super(opis, sifra, uvoznaCijena);
        this.operativniSistem = operativniSistem;
        this.velicinaEkrana = velicinaEkrana;
    }

    public String getOperativniSistem() {
        return operativniSistem;
    }

    public double getVelicinaEkrana() {
        return velicinaEkrana;
    }

    @Override
    public double maloprodajnaCijena() {
        double c = osnovnaMaloprodajnaCijena();
        if (velicinaEkrana > 6.0) {
            return c * 1.03;
        }
        return c;
    }

    @Override
    public String toString() {
        return String.format("[TE] %s | %s | OS: %s | Ekran: %.1f\" | Uvozna: %.2f | Maloprodajna: %.2f",
                opis, sifra, operativniSistem, velicinaEkrana, uvoznaCijena, maloprodajnaCijena());
    }
}
