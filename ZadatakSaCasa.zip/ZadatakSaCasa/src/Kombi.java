
public class Kombi extends Vozilo {

	int kapacitetPutnika;

	public Kombi(String p, int g, int k, String b, int kapacitetPutnika) {
	super(p, g, k, b);
	this.kapacitetPutnika = kapacitetPutnika;
	}

	@Override
	public double cijenaRegistracije() {
	double cijena = super.cijenaRegistracije();
	cijena += 30; // dodatak za kombi
	return cijena;
	}

	@Override
	public void prikaziPodatke() {
	super.prikaziPodatke();
	System.out.println("Kapacitet putnika: " + kapacitetPutnika);
	}

}
