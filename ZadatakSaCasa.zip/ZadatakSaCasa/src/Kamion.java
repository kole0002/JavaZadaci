
public class Kamion extends Vozilo {
	int kapacitetTereta;
	boolean imaPrikolicu;
	
	public Kamion(String p, int g, int k, String b, int kapacitetTereta, boolean imaPrikolicu) {
		super(p, g, k, b);
		this.kapacitetTereta = kapacitetTereta;
		this.imaPrikolicu = imaPrikolicu;
		}
	
	@Override
	public double cijenaRegistracije() {
	double cijena = super.cijenaRegistracije();
	cijena += 20; // dodatak za kamion
	if (imaPrikolicu) cijena += 50;
	return cijena;
	}

	@Override
	public void prikaziPodatke() {
	super.prikaziPodatke();
	System.out.println("Kapacitet tereta: " + kapacitetTereta + " kg");
	System.out.println("Ima prikolicu: " + (imaPrikolicu ? "da" : "ne"));
	}

}
