
public class Vozilo {
	String proizvodjac;
	int godinaProizvodnje;
	int kubikaza;
	String boja;

	public Vozilo(String proizvodjac, int godinaProizvodnje, int kubikaza, String boja) {
	this.proizvodjac = proizvodjac;
	this.godinaProizvodnje = godinaProizvodnje;
	this.kubikaza = kubikaza;
	this.boja = boja;
	}

	public double cijenaRegistracije() {
		double cijena = 100;
		if (godinaProizvodnje < 2010) cijena += 30;
		if (kubikaza > 2000) cijena += 50;
		return cijena;
		}
	
	public void prikaziPodatke() {
		System.out.println("Proizvođač: " + proizvodjac);
		System.out.println("Godina: " + godinaProizvodnje);
		System.out.println("Kubikaža: " + kubikaza);
		System.out.println("Boja: " + boja);
		System.out.println("Cijena registracije: " + cijenaRegistracije() + " EUR");
		}

	public static void main(String[] args) {
		Automobil a = new Automobil("Audi", 2015, 1800, "crna", 4, "dizel");
		Kamion k = new Kamion("Mercedes", 2007, 3000, "crvena", 5000, true);
		Kombi ko = new Kombi("Volvo", 2010, 2200, "bijela", 8);

		System.out.println("=== AUTOMOBIL ===");
		a.prikaziPodatke();
		System.out.println("\n=== KAMION ===");
		k.prikaziPodatke();
		System.out.println("\n=== KOMBI ===");
		ko.prikaziPodatke();
	}
}
	