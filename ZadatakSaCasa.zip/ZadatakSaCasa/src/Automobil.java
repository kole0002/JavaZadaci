
public class Automobil extends Vozilo{
	int brojVrata;
	String tipMotora;

	public Automobil(String p, int g, int k, String b, int brojVrata, String tipMotora) {
		super(p, g, k, b);
		this.brojVrata = brojVrata;
		this.tipMotora = tipMotora;
		}

		@Override
		public double cijenaRegistracije() {
		double cijena = super.cijenaRegistracije();
		cijena += 50; 
		return cijena;
		}

		@Override
		public void prikaziPodatke() {
		super.prikaziPodatke();
		System.out.println("Broj vrata: " + brojVrata);
		System.out.println("Tip motora: " + tipMotora);
		}
		
}
